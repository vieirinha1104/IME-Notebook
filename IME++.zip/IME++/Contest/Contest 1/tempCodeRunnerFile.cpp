
    cin.tie(0);
    ios_base::sync_with_stdio(false);